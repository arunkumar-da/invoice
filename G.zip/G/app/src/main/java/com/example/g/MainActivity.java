package com.example.g;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.Toast;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.FontSelector;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button button;
    private static final int STORAGE_CODE = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);


        //handle button click
        button.setOnClickListener(v -> {

            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {

                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                        PackageManager.PERMISSION_DENIED) {

                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    requestPermissions(permissions, STORAGE_CODE);
                } else {

                    savePdf();
                }
            } else {

                savePdf();
            }
        });

    }

    private void savePdf() {
        Document mDoc = new Document();

        String mFileName = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(System.currentTimeMillis());

        String mFilePath = Environment.getExternalStorageDirectory() + "/" + mFileName + ".pdf";
        try {

            PdfWriter.getInstance(mDoc, new FileOutputStream(mFilePath));

            mDoc.open();
            PdfPTable h = new PdfPTable(1); //one page contains 15 records
            h.setWidthPercentage(110);
            h.setWidths(new float[] { 15});
            FontSelector f = new FontSelector();
            Font font1 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 25, Font.NORMAL, BaseColor.BLACK);
            f.addFont(font1);
            Phrase brand = f.process(" TAX INVOICE");
            Paragraph A =new Paragraph(brand);


            FontSelector f1 = new FontSelector();
            Font font2 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.NORMAL, BaseColor.BLACK);
            f1.addFont(font2);
            Phrase brand1 = f1.process(" DHANU INDIA TRADERS");
            Paragraph A1 =new Paragraph(brand1);
            FontSelector f2 = new FontSelector();
            Font font3 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.NORMAL, BaseColor.BLACK);
            f2.addFont(font3);
            Phrase brand2 = f2.process(" 2/A PALAYANIYANDI STREET,THOOTHUKUDI ROAD,NAMAKAL-123456");
            Paragraph A2 =new Paragraph(brand2);
            PdfPTable irdTable1= new PdfPTable(2);
            irdTable1.setWidthPercentage(110);

            irdTable1.addCell(getIRDCell1("TO:ARUN KUMAR V"));
            irdTable1.addCell(getIRDCell("BILL NO:123"));
            irdTable1.addCell(getIRDCell1("GSTIN:1234567890")); // pass invoice number
            irdTable1.addCell(getIRDCell("BILL DATE:22/22/2222"));
            irdTable1.addCell(getIRDCell1("MOBILE NUMBER:866767354")); // pass invoice number
            irdTable1.addCell(getIRDCell("DUE DATE:22/22/2323"));// pass invoice date

            h.addCell(getIRDCell4((A)));
            h.addCell(getIRDCell5((A1)));
            h.addCell(getIRDCell5((A2)));
            PdfPTable table2 = new PdfPTable(6);

            table2.setWidthPercentage(110);
            table2.setWidths(new float[] { 3,3,2,2,8,5});
            table2.addCell("NO TAX");
            table2.addCell("54995.00");
            table2.addCell("CGST");
            table2.addCell("SGST");
            table2.addCell("BANK DEATAILS");
            table2.addCell("GROSS:");
            table2.addCell(getBillRowCell("GST5%"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getIRDCell7("A/C Name: ADHITYA SEMAN BANK"));
            table2.addCell(("DISCOUNT:"));
            table2.addCell(getBillRowCell("GST12%"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getIRDCell7("A/C NO:12345667890 IFSC:AIIA0212680"));
            table2.addCell(("CGST:"));
            table2.addCell(getBillRowCell("GST18%"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getBillRowCell("0.00"));
            table2.addCell(getIRDCell7("ALLAHABAD BANK, KANNADHERI BRANCH"));
            table2.addCell(("SGST:"));
            table2.addCell(getBillRowCell2("GST28%"));
            table2.addCell(getBillRowCell2("0.00"));
            table2.addCell(getBillRowCell2("0.00"));
            table2.addCell(getBillRowCell2("0.00"));
            table2.addCell(getBillRowCell3("PH NO:122567890"));
            table2.addCell(("PRE\nBAL:"));
            table2.addCell(("NO TAX"));
            table2.addCell(("54995.00"));
            table2.addCell(("0.00"));
            table2.addCell(("0.00"));
            table2.addCell("GROSS:");
            PdfPTable table3= new PdfPTable(3);

            table3.setWidthPercentage(110);
            table3.setWidths(new float[] { 8,6,4});
            table3.addCell(getIRDCell9("TWENTY FIVE THOUSAND ONLY /-"));
            table3.addCell(("Total quantity :123"));
            table3.addCell(("TOTAL:76877"));
            PdfPTable heading = new PdfPTable(4);

            heading.setWidthPercentage(110);
            heading.setWidths(new float[] { 2,7,3,5});

            PdfPTable billTable = new PdfPTable(12);
            PdfPCell cell2;
            cell2 = new PdfPCell(getBillHeaderCell1(new Paragraph("CGST")));
            cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell2.setColspan(2);
            //one page contains 15 records
            billTable.setWidthPercentage(110);
            billTable.setWidths(new float[] { 1,5,2,2,2,2,2,2,2,2,2,4 });

            billTable.addCell(getBillHeaderCell("no"));
            billTable.addCell(getBillHeaderCell("particulars"));
            billTable.addCell(getBillHeaderCell("HSN"));
            billTable.addCell(getBillHeaderCell("qty"));
            billTable.addCell(getBillHeaderCell("Rate"));
            billTable.addCell(getBillHeaderCell("Dis%"));
            billTable.addCell(getBillHeaderCell("Nett"));
            billTable.addCell((cell2));
            cell2 = new PdfPCell(getBillHeaderCell1(new Paragraph("SGST")));
            cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell2.setColspan(2);
            billTable.addCell((cell2));
            billTable.addCell(getBillHeaderCell2("AMOUNT"));
            billTable.addCell(getBillHeaderCell2(""));
            billTable.addCell(getBillHeaderCell2(""));
            billTable.addCell(getBillHeaderCell2(""));
            billTable.addCell(getBillHeaderCell2(""));
            billTable.addCell(getBillHeaderCell2(""));
            billTable.addCell(getBillHeaderCell2(""));
            billTable.addCell(getBillHeaderCell2(""));
            billTable.addCell(getBillHeaderCell2("TAX"));
            billTable.addCell(getBillHeaderCell2("AMT"));
            billTable.addCell(getBillHeaderCell2("TAX"));
            billTable.addCell(getBillHeaderCell2("AMT"));
            billTable.addCell(getBillHeaderCell2(""));

            billTable.addCell(getBillRowCell("1"));
            billTable.addCell(getBillRowCell1("IPHONE XR 2020"));
            billTable.addCell(getBillRowCell1("511"));
            billTable.addCell(getBillRowCell("1500 DOS"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("12"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("12"));
            billTable.addCell(getBillRowCell("121"));
            billTable.addCell(getBillRowCell("13"));
            billTable.addCell(getBillRowCell("312"));
            billTable.addCell(getBillRowCell("21780.00"));
            billTable.addCell(getBillRowCell("1"));
            billTable.addCell(getBillRowCell1("IPHONE XR 2020"));
            billTable.addCell(getBillRowCell1("511"));
            billTable.addCell(getBillRowCell("1500 DOS"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("12"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("2"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("3"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("21780.00"));
            billTable.addCell(getBillRowCell("1"));
            billTable.addCell(getBillRowCell1("IPHONE XR 2020"));
            billTable.addCell(getBillRowCell1("511"));
            billTable.addCell(getBillRowCell("1500 DOS"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("12"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("2"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("3"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("21780.00"));
            billTable.addCell(getBillRowCell("1"));
            billTable.addCell(getBillRowCell1("IPHONE XR 2020"));
            billTable.addCell(getBillRowCell1("511"));
            billTable.addCell(getBillRowCell("1500 DOS"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("12"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("2"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("3"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("21780.00"));
            billTable.addCell(getBillRowCell("1"));
            billTable.addCell(getBillRowCell1("IPHONE XR 2020"));
            billTable.addCell(getBillRowCell1("511"));
            billTable.addCell(getBillRowCell("1500 DOS"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("12"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("2"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("3"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("21780.00"));
            billTable.addCell(getBillRowCell("1"));
            billTable.addCell(getBillRowCell1("IPHONE XR 2020"));
            billTable.addCell(getBillRowCell1("511"));
            billTable.addCell(getBillRowCell("1500 DOS"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("12"));
            billTable.addCell(getBillRowCell("14.50"));
            billTable.addCell(getBillRowCell("2"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("3"));
            billTable.addCell(getBillRowCell("123"));
            billTable.addCell(getBillRowCell("21780.00"));


            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));
            billTable.addCell(getBillRowCell(""));



            mDoc.add(h);
            mDoc.add(irdTable1);


            mDoc.add(heading);
            mDoc.add(billTable);

            mDoc.add(table2);
            mDoc.add(table3);
            mDoc.close();
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }
    public static PdfPCell getIRDCell5(Paragraph text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);
        cell.setBorderWidthBottom(0);
        cell.setBorderWidthTop(0);


        return cell;
    }
    public static PdfPCell getIRDCell9(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setFixedHeight(30);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);



        return cell;
    }
    public static PdfPCell getIRDCell4(Paragraph text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setFixedHeight(40);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);
        cell.setBorderWidthBottom(0);



        return cell;
    }
    public static PdfPCell getIRDCell(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.BLACK);

        return cell;
    }
    public static PdfPCell getIRDCell1(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_LEFT);
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.BLACK);

        return cell;
    }
    public static PdfPCell getBillRowCell3(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_LEFT);
        cell.setPadding (5.0f);
        cell.setBorderWidthTop(0);
        return cell;
    }
    public static PdfPCell getBillRowCell1(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_LEFT);
        cell.setPadding (5.0f);

        cell.setBorderWidthBottom(0);
        cell.setBorderWidthTop(0);
        return cell;
    }
    public static PdfPCell getBillRowCell(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
        cell.setPadding (5.0f);

        cell.setBorderWidthBottom(0);
        cell.setBorderWidthTop(0);
        return cell;
    }
    public static PdfPCell getBillRowCell2(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
        cell.setPadding (5.0f);
        cell.setBorderWidthTop(0);
        return cell;
    }
    public static PdfPCell getIRDCell7(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 11);
        font.setColor(BaseColor.BLACK);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        cell = new PdfPCell(phrase);
        cell.setHorizontalAlignment (Element.ALIGN_LEFT);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.WHITE);
        return cell;
    }
    public static PdfPCell getBillHeaderCell(String text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 13);
        font.setColor(BaseColor.RED);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        PdfPCell cell = new PdfPCell (phrase);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setBorderWidthBottom(0);
        cell.setBorderWidthTop(0);
        return cell;
    }
    public static PdfPCell getBillHeaderCell1(Paragraph text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 13);
        font.setColor(BaseColor.RED);
        fs.addFont(font);
        Phrase phrase = fs.process(String.valueOf(text));
        PdfPCell cell = new PdfPCell (phrase);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);

        return cell;
    }
    public static PdfPCell getBillHeaderCell2(String text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 13);
        font.setColor(BaseColor.RED);
        fs.addFont(font);
        Phrase phrase = fs.process(String.valueOf(text));
        PdfPCell cell = new PdfPCell (phrase);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);

        return cell;
    }


    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                savePdf();

            } else {

                Toast.makeText(this, "Permission denied...!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
