package com.example.invoice3;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;


import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.itextpdf.text.BaseColor;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.FontSelector;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText mTextEt;
    Button mSaveBtn,button,button3,button4;

    private static final int STORAGE_CODE = 1000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.button1);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        mTextEt = findViewById(R.id.textEt);
        mSaveBtn = findViewById(R.id.saveBtn);

        //handle button click
        mSaveBtn.setOnClickListener(v -> {

            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M){

                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                        PackageManager.PERMISSION_DENIED){

                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    requestPermissions(permissions, STORAGE_CODE);
                }
                else {

                    savePdf();
                }
            }
            else {

                savePdf();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M){

                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                            PackageManager.PERMISSION_DENIED){

                        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permissions, STORAGE_CODE);
                    }
                    else {

                        savePdf1();
                    }
                }
                else {

                    savePdf1();
                }
            }


        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M){

                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                            PackageManager.PERMISSION_DENIED){

                        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permissions, STORAGE_CODE);
                    }
                    else {

                        savePdf2();
                    }
                }
                else {

                    savePdf2();
                }
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M){

                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                            PackageManager.PERMISSION_DENIED){

                        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permissions, STORAGE_CODE);
                    }
                    else {

                        savePdf3();
                    }
                }
                else {

                    savePdf3();
                }
            }


        });

    }

    private void savePdf3() {
        Document mDoc = new Document();

        String mFileName = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(System.currentTimeMillis());

        String mFilePath = Environment.getExternalStorageDirectory() + "/" + mFileName + ".pdf";

        try {

            PdfWriter.getInstance(mDoc, new FileOutputStream(mFilePath));

            mDoc.open();
            Image image = null;
            try {
                Drawable d = getResources().getDrawable(R.drawable.g);
                BitmapDrawable bitDw = ((BitmapDrawable) d);
                Bitmap bmp = bitDw.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                image = Image.getInstance(stream.toByteArray());
                image.scaleAbsolute(540f, 72f);//image width,height

            } catch (Exception e) {
                image = null;
            }

            PdfPTable heading = new PdfPTable(2); //one page contains 15 records
            heading.setWidthPercentage(110);
            heading.setWidths(new float[] { 7,7 });
            heading.setSpacingBefore(30.0f);
            Paragraph b =new Paragraph();
            b.add("INVOICE NO: 12345");
            b.add("\n\nDUE DATE:24 JUNE 2020");
            b.add("\n\nCLIENT:");
            b.add("\n\n9042133726");
            b.add("\n\n8667673544");
            b.add("\n\nDEDWED@GMAIL.COM");

            heading.addCell(getIRDCell10(b));
            heading.addCell(image);
            PdfPTable billTable = new PdfPTable(4);
            //one page contains 15 records
            billTable.setWidthPercentage(100);
            billTable.setWidths(new float[] {  2,7,2,2 });
            billTable.setSpacingBefore(30.0f);
            billTable.addCell(getIRDCell12("QTY"));
            billTable.addCell(getIRDCell12("Description"));
            billTable.addCell(getIRDCell12("PRICE"));
            billTable.addCell(getIRDCell12("TOTAL"));

            Paint paint = new Paint();
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(1f);
            int startX = 20;
            int startY = 100;
            int  stopX = 140;
            int  stopY = 30;
            Canvas canvas = new Canvas();
            canvas.drawLine(startX, startY, stopX, stopY, paint);
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));


            billTable.addCell(getIRDCell13("1"));
            billTable.addCell(getIRDCell13("Your item name"));
            billTable.addCell(getIRDCell13("$0 "));
            billTable.addCell(getIRDCell13("1"));

            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));

            billTable.addCell(getIRDCell13("1"));
            billTable.addCell(getIRDCell13("Your item name"));
            billTable.addCell(getIRDCell13("$0 "));
            billTable.addCell(getIRDCell13("1"));

            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));

            billTable.addCell(getIRDCell13("1"));
            billTable.addCell(getIRDCell13("Your item name"));
            billTable.addCell(getIRDCell13("$0 "));
            billTable.addCell(getIRDCell13("1"));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell13(""));
            billTable.addCell(getIRDCell13(" "));
            billTable.addCell(getIRDCell13("Subtotal"));
            billTable.addCell(getIRDCell13("$0"));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell4("tax"));
            billTable.addCell(getIRDCell4("$0"));
            billTable.addCell(getIRDCell13(""));
            billTable.addCell(getIRDCell13(" "));
            billTable.addCell(getIRDCell13("total"));
            billTable.addCell(getIRDCell13("$0"));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell4(""));
            FontSelector fs = new FontSelector();
            Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.BOLDITALIC);
            fs.addFont(font);
            Phrase bill = fs.process("CLIENT NAME"); // customer information
            Paragraph name = new Paragraph("850 SYLAN STREET");
            name.setIndentationLeft(20);
            Paragraph contact = new Paragraph("SOUTH ANGELON STREET");
            contact.setIndentationLeft(20);
            FontSelector fs1 = new FontSelector();
            Font font1 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.BOLDITALIC);
            fs1.addFont(font1);
            Paragraph P= new Paragraph("Designed by iconx");
            Image image1 = null;
            try {
                Drawable d = getResources().getDrawable(R.drawable.i);
                BitmapDrawable bitDw = ((BitmapDrawable) d);
                Bitmap bmp = bitDw.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                image1 = Image.getInstance(stream.toByteArray());
                image1.scaleAbsolute(140f, 22f);//image width,height

            } catch (Exception e) {
                image1 = null;
            }

            Paragraph AD = new Paragraph("\n Goods once sold will not be taken back or exchanged || Subject to product justification || Product damage no one responsible || "
                    + " Service only at concarned authorized service centers");
mDoc.add(heading);


            mDoc.add(billTable);
            mDoc.add(bill);
            mDoc.add(name);
            mDoc.add(contact);

mDoc.add(P);

mDoc.add(AD);
            mDoc.close();
            Toast.makeText(this, mFileName +".pdf\nis saved to\n"+ mFilePath, Toast.LENGTH_SHORT).show();

        }
        catch (Exception e){

            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    private void savePdf() {

        Document mDoc = new Document();

        String mFileName = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(System.currentTimeMillis());

        String mFilePath = Environment.getExternalStorageDirectory() + "/" + mFileName + ".pdf";

        try {

            PdfWriter.getInstance(mDoc, new FileOutputStream(mFilePath));

            mDoc.open();


            PdfPTable heading = new PdfPTable(2); //one page contains 15 records
            heading.setWidthPercentage(110);
            heading.setWidths(new float[] { 1,7});
            Image image = null;
            try {
                Drawable d = getResources().getDrawable(R.drawable.s);
                BitmapDrawable bitDw = ((BitmapDrawable) d);
                Bitmap bmp = bitDw.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                image = Image.getInstance(stream.toByteArray());
                image.scaleAbsolute(40f, 2f);//image width,height

            } catch (Exception e) {
                image = null;
            }
            heading.addCell(image);

            FontSelector f = new FontSelector();
            Font font1 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 39, Font.NORMAL, BaseColor.WHITE);
            f.addFont(font1);
            Phrase brand = f.process(" Iconx Technology");

            Paragraph A =new Paragraph(brand);
A.add("\nmahilchipuram,permalpuram post");
            A.add("\ntirunelveli-63002");
            heading.addCell(getIRDCell5((A)));

            PdfPTable ac = new PdfPTable(2);
            ac.setWidthPercentage(100);
            ac.setWidths(new float[] { 6, 4 });
            ac.setSpacingBefore(30.0f);
            ac.addCell(getIRDCell14("INVOICE TO:"));
            ac.addCell(getIRDCell15("invoice no:72598"));
            ac.addCell(getIRDCell14("Star won Inc"));
            ac.addCell(getIRDCell15("date:11/06/2022"));
            ac.addCell(getIRDCell14("phone:1234567895"));
            ac.addCell(getIRDCell15("due date:30/06/2022"));
            ac.addCell(getIRDCell14("rasul7@gmail.com"));
            ac.addCell(getIRDCell15("estimate time:Nil"));
            ac.addCell(getIRDCell14("GSTIN:33086HGFI232"));

            FontSelector fs = new FontSelector();
            Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.BOLDITALIC);
            fs.addFont(font);





            PdfPTable billTable = new PdfPTable(5);
            //one page contains 15 records
            billTable.setWidthPercentage(100);
            billTable.setWidths(new float[] {  2,7,2,1,2 });
            billTable.setSpacingBefore(30.0f);
            billTable.addCell(getIRDCell12("QTY"));
            billTable.addCell(getIRDCell12("Description"));
            billTable.addCell(getIRDCell12("PRICE"));
            billTable.addCell(getIRDCell12("GST"));
            billTable.addCell(getIRDCell12("TOTAL"));

            Paint paint = new Paint();
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(1f);
            int startX = 20;
            int startY = 100;
            int  stopX = 140;
            int  stopY = 30;
            Canvas canvas = new Canvas();
            canvas.drawLine(startX, startY, stopX, stopY, paint);
            billTable.addCell(getIRDCell4("3"));
            billTable.addCell(getIRDCell4("f2C printer"));
            billTable.addCell(getIRDCell4("3100 "));
            billTable.addCell(getIRDCell4("18% "));
            billTable.addCell(getIRDCell4("9858"));


            billTable.addCell(getIRDCell13("1"));
            billTable.addCell(getIRDCell13("Epson L3110 Printer"));
            billTable.addCell(getIRDCell13("15,700 "));
            billTable.addCell(getIRDCell13("18% "));
            billTable.addCell(getIRDCell13("18526"));

            billTable.addCell(getIRDCell4("4"));
            billTable.addCell(getIRDCell4("Android Billing Software"));
            billTable.addCell(getIRDCell4("5,400 "));
            billTable.addCell(getIRDCell4("5% "));
            billTable.addCell(getIRDCell4("5670"));

            billTable.addCell(getIRDCell13("1"));
            billTable.addCell(getIRDCell13("System Billing Software"));
            billTable.addCell(getIRDCell13("35,000 "));
            billTable.addCell(getIRDCell13("5% "));
            billTable.addCell(getIRDCell13("36,750"));

            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4("subtotal "));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell13("70,804"));



            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell4("Round off"));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell13("0"));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell4("Total"));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell13("70,804"));



            mDoc.addAuthor("Atif Pervaiz");



            Paragraph thanks = new Paragraph(String.valueOf(getdescCell("Amount in Words: Seventy thousand eight hundred and four ")));
            FontSelector fs3= new FontSelector();
            font = FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.ITALIC);
            fs.addFont(font);

            Phrase payment  = fs.process("\n \n \nPAYMENT INFO:");
            PdfPTable irdTable1= new PdfPTable(2);


            irdTable1.addCell(getIRDCell("Account No"));
            irdTable1.addCell(getIRDCell(" 8870935696"));
            irdTable1.addCell(getIRDCell("Account Name")); // pass invoice number
            irdTable1.addCell(getIRDCell("Iconx Technology"));
            irdTable1.addCell(getIRDCell("Bank Details")); // pass invoice number
            irdTable1.addCell(getIRDCell("kotak mahindra bank\ntirunelveli\nKKBK0008793"));// pass invoice date


            Paragraph AD = new Paragraph("\n Thank you for bussiness ,keep supporting us");
            Paragraph P= new Paragraph("Designed by iconx");
            Image image1 = null;
            try {
                Drawable d = getResources().getDrawable(R.drawable.i);
                BitmapDrawable bitDw = ((BitmapDrawable) d);
                Bitmap bmp = bitDw.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                image1 = Image.getInstance(stream.toByteArray());
                image1.scaleAbsolute(140f, 22f);//image width,height

            } catch (Exception e) {
                image = null;
            }

            String mText = mTextEt.getText().toString();
        mDoc.add(heading);
           mDoc.add(ac);
            mDoc.add(new Paragraph(mText));

        mDoc.add(billTable);

       


            mDoc.add(new Paragraph(thanks));
            mDoc.add(payment);

          mDoc.add(irdTable1);
          mDoc.add(AD );

mDoc.add(P);
mDoc.add(image1);







            mDoc.close();
            Toast.makeText(this, mFileName +".pdf\nis saved to\n"+ mFilePath, Toast.LENGTH_SHORT).show();
        }
        catch (Exception e){

            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private void savePdf1() {
        Document mDoc = new Document();

        String mFileName = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(System.currentTimeMillis());

        String mFilePath = Environment.getExternalStorageDirectory() + "/" + mFileName + ".pdf";
        try {

            PdfWriter.getInstance(mDoc, new FileOutputStream(mFilePath));

            mDoc.open();
            Paragraph ad =new Paragraph();
            ad.add("Vyapar Tech Solutions\n");
            ad.add("#41,classic crest, kornamagal ,bangalore 31\n");
            ad.add("ph no: 8667673544 \n");
            ad.add("GSTIN 1234558760898U8\n");
            FontSelector f = new FontSelector();

            Font font1 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 35, Font.NORMAL, BaseColor.GREEN);
            f.addFont(font1);

            Phrase brand = f.process("\n \n\nTAX INVOICE");
Paragraph aa = new Paragraph(brand);
           aa.setAlignment(Element.ALIGN_CENTER);

            PdfPTable ac = new PdfPTable(2);
           ac.setWidthPercentage(100);
            ac.setWidths(new float[] { 6, 4 });
            ac.setSpacingBefore(30.0f);
            ac.addCell(getIRDCell4("Bill to:"));
            ac.addCell(getIRDCell4("classic: enterprises"));
            ac.addCell(getIRDCell4("marathaliu road bangalore"));
            ac.addCell(getIRDCell4("phone:123456789"));
            ac.addCell(getIRDCell4("invoice no:1236535235"));
            ac.addCell(getIRDCell4("date:878r7r8"));
            ac.addCell(getIRDCell4("due date:1212323"));
            ac.addCell(getIRDCell4("estimate time:4234"));
            PdfPTable billTable = new PdfPTable(4);
            //one page contains 15 records
            billTable.setWidthPercentage(100);
            billTable.setWidths(new float[] {  9,2,2,2 });
            billTable.setSpacingBefore(30.0f);

            billTable.addCell(getIRDCell1("Description"));
            billTable.addCell(getIRDCell1("Unit cost"));
            billTable.addCell(getIRDCell1("Qty/Hr rate"));
            billTable.addCell(getIRDCell1("Amount"));
            Paint paint = new Paint();
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(1f);
            int startX = 20;
            int startY = 100;
            int  stopX = 140;
            int  stopY = 30;
            Canvas canvas = new Canvas();
            canvas.drawLine(startX, startY, stopX, stopY, paint);
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("$0"));
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell4("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell4("$0"));
            billTable.addCell(getIRDCell1(""));
            billTable.addCell(getIRDCell1(" "));
            billTable.addCell(getIRDCell1("Subtotal"));
            billTable.addCell(getIRDCell1("$0"));
            billTable.addCell(getIRDCell4("TERMS&CONDITION"));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell4("Discount"));
            billTable.addCell(getIRDCell1("$0"));
            billTable.addCell(getIRDCell4(""));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell1("(Tax rate)"));
            billTable.addCell(getIRDCell1("0%"));
            billTable.addCell(getIRDCell4("\t \t \t \t \t \t \t \t \t Please Pay Invoice by MM/DD/YYYY"));
            billTable.addCell(getIRDCell4(" "));
            billTable.addCell(getIRDCell1("Tax"));
            billTable.addCell(getIRDCell1("$0"));
            PdfPTable   total = new PdfPTable(4);
            //one page contains 15 records
            total.setWidthPercentage(100);
            total.setWidths(new float[] {  9,3,2,5});
            total.setSpacingBefore(20.0f);
            total.addCell(getIRDCell4(""));
            total.addCell(getIRDCell4(" "));
            total.addCell(getIRDCell4(""));
            total.addCell(getIRDCell4("Invoice Total $2000"));
            Paragraph a =new Paragraph("\n\nPay to ABC National bank");
            Paragraph a1 =new Paragraph("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAmount name arunkumar");
            Image image = null;
            try {
                Drawable d = getResources().getDrawable(R.drawable.o);
                BitmapDrawable bitDw = ((BitmapDrawable) d);
                Bitmap bmp = bitDw.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                image = Image.getInstance(stream.toByteArray());
                image.scaleAbsolute(540f, 72f);//image width,height

            } catch (Exception e) {
                image = null;
            }

            mDoc.add(ad);
mDoc.add(aa);
mDoc.add(ac);
mDoc.add(billTable);
mDoc.add(total);
mDoc.add(a);
            mDoc.add(a1);
            if(image!=null)
            mDoc.add(image);
            mDoc.close();
            Toast.makeText(this, mFileName +".pdf\nis saved to\n"+ mFilePath, Toast.LENGTH_SHORT).show();
        }
        catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private void savePdf2() {
        Document mDoc = new Document();

        String mFileName = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(System.currentTimeMillis());
        String mFilePath = Environment.getExternalStorageDirectory() + "/" + mFileName + ".pdf";
        try {
            PdfWriter.getInstance(mDoc, new FileOutputStream(mFilePath));
            mDoc.open();
            PdfPTable heading = new PdfPTable(3); //one page contains 15 records
            heading.setWidthPercentage(110);
            heading.setWidths(new float[] { 7,4,4 });
            FontSelector f = new FontSelector();
            Font font1 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 55, Font.NORMAL, BaseColor.WHITE);
            f.addFont(font1);
            Phrase brand = f.process(" INVOICE");

            Paragraph A =new Paragraph(brand);

            heading.addCell(getIRDCell5((A)));
            FontSelector f1 = new FontSelector();
            Font font2 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 15, Font.NORMAL, BaseColor.WHITE);
            f1.addFont(font2);
            Phrase brand1 = f1.process(" 647-444-1234 \nyour@email.com\nyour website.com");

            Paragraph A1 =new Paragraph(brand1);
            heading.addCell(getIRDCell5(A1));
            FontSelector f2 = new FontSelector();
            Font font3= FontFactory.getFont(FontFactory.TIMES_ROMAN, 15, Font.NORMAL, BaseColor.WHITE);
            f2.addFont(font3);
            Phrase brand2 = f2.process("1 Your Address\nCity,State,Country\nZip Code");
            Paragraph A3 =new Paragraph(brand2);
            heading.addCell(getIRDCell5((A3)));
            PdfPTable table = new  PdfPTable(2);
            table.setWidthPercentage(60);
            table.setWidths(new float[] { 2,2 });
            table.setSpacingBefore(20.0f);
            table.setHorizontalAlignment(3);

            table.addCell(getIRDCell6("Invoice number"));
            table.addCell(getIRDCell6("000001"));

            table.addCell(getIRDCell6("Date of issue"));
            table.addCell(getIRDCell6("mm/dd/yyyy"));
            PdfPTable table2 = new  PdfPTable(2);
            table2.setWidthPercentage(60);
            table2.setWidths(new float[] { 2,2 });
            table2.setSpacingBefore(30.0f);
            table2.setHorizontalAlignment(3);

            table2.addCell(getIRDCell6("BILLED TO"));
            table2.addCell(getIRDCell6("YOUR COMPANY NAME"));

            table2.addCell(getIRDCell6("CLIENT NAME"));
            table2.addCell(getIRDCell6("123 YOUR STREET"));
            table2.addCell(getIRDCell6("STREET ADDRESS"));
            table2.addCell(getIRDCell6("564-555-1234"));

            table2.addCell(getIRDCell6("CITY,STATE,COUNTRY"));
            table2.addCell(getIRDCell6("YOUR@email.com"));
            table2.addCell(getIRDCell6("ZIP CODE"));
            table2.addCell(getIRDCell6("YOUR@WEBSITE.com"));
            Canvas canvas = new Canvas();
            PdfPTable billTable = new PdfPTable(4);
            //one page contains 15 records
            billTable.setWidthPercentage(100);
            billTable.setWidths(new float[] {  9,2,2,2 });
            billTable.setSpacingBefore(30.0f);

            billTable.addCell(getIRDCell1("Description"));
            billTable.addCell(getIRDCell1("Unit cost"));
            billTable.addCell(getIRDCell1("Qty/Hr rate"));
            billTable.addCell(getIRDCell1("Amount"));
            Paint paint = new Paint();
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(1f);
            int startX = 20;
            int startY = 100;
            int  stopX = 140;
            int  stopY = 30;
            canvas.drawLine(startX, startY, stopX, stopY, paint);
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell7("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell7("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell7("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell7("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell7("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell7("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell7("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell7("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell7("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell7("$0"));

            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell7("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell7("$0"));
            billTable.addCell(getIRDCell4("Your item name"));
            billTable.addCell(getIRDCell7("$0 "));
            billTable.addCell(getIRDCell4("1"));
            billTable.addCell(getIRDCell7("$0"));
            billTable.addCell(getIRDCell1(""));
            billTable.addCell(getIRDCell1(" "));
            billTable.addCell(getIRDCell1("Subtotal"));
            billTable.addCell(getIRDCell1("$0"));
            billTable.addCell(getIRDCell6("TERMS&CONDITION"));
            billTable.addCell(getIRDCell6(" "));
            billTable.addCell(getIRDCell1("Discount"));
            billTable.addCell(getIRDCell1("$0"));
            billTable.addCell(getIRDCell6(""));
            billTable.addCell(getIRDCell6(" "));
            billTable.addCell(getIRDCell1("(Tax rate)"));
            billTable.addCell(getIRDCell1("0%"));
            billTable.addCell(getIRDCell6("\t \t \t \t \t \t \t \t \t Please Pay Invoice by MM/DD/YYYY"));
            billTable.addCell(getIRDCell6(" "));
            billTable.addCell(getIRDCell1("Tax"));
            billTable.addCell(getIRDCell1("$0"));
            PdfPTable   total = new PdfPTable(4);
            //one page contains 15 records
            total.setWidthPercentage(100);
            total.setWidths(new float[] {  9,3,2,5});

            total.setSpacingBefore(20.0f);
            total.addCell(getIRDCell6(""));
            total.addCell(getIRDCell6(" "));
            total.addCell(getIRDCell6(""));
            total.addCell(getIRDCell3("Invoice Total $2000"));
            Paragraph P= new Paragraph("Designed by iconx");
            Image image = null;
            try {
                Drawable d = getResources().getDrawable(R.drawable.i);
                BitmapDrawable bitDw = ((BitmapDrawable) d);
                Bitmap bmp = bitDw.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                image = Image.getInstance(stream.toByteArray());
                image.scaleAbsolute(140f, 22f);//image width,height

            } catch (Exception e) {
                image = null;
            }

            mDoc.add(heading);
            mDoc.add(table);
            mDoc.add(table2);
            mDoc.add(billTable);
            mDoc.add(total);
            mDoc.add(P);
            if(image!=null)
            mDoc.add(image);
            mDoc.close();
            Toast.makeText(this, mFileName +".pdf\nis saved to\n"+ mFilePath, Toast.LENGTH_SHORT).show();
        }
        catch (Exception e){

            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }



    public static PdfPCell getIRHCell(String text, int alignment) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 16);
        /*	font.setColor(BaseColor.GRAY);*/
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        PdfPCell cell = new PdfPCell(phrase);
        cell.setPadding(5);
        cell.setHorizontalAlignment(alignment);
        cell.setBorder(PdfPCell.NO_BORDER);
        return cell;
    }

    public static PdfPCell getIRDCell6(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (3.0f);
        cell.setBorderColor(BaseColor.WHITE);

        return cell;
    }

    public static PdfPCell getIRDCell(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.LIGHT_GRAY);
        return cell;
    }
    public static PdfPCell getIRDCell4(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 11);
        font.setColor(BaseColor.BLACK);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        cell = new PdfPCell(phrase);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.WHITE);
        return cell;
    }
    public static PdfPCell getIRDCell7(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 11);
        font.setColor(BaseColor.BLACK);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        cell = new PdfPCell(phrase);
        cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.WHITE);
        return cell;
    }
    public static PdfPCell getIRDCell5(Paragraph text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setFixedHeight(80);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);
        BaseColor O2 = new BaseColor(130,111,155);
        cell.setBackgroundColor(O2);

        return cell;
    }
    public static PdfPCell getIRDCell14(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.WHITE);

        cell.setHorizontalAlignment (Element.ALIGN_LEFT);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);


        return cell;
    }
    public static PdfPCell getIRDCell15(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.WHITE);

        cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);


        return cell;
    }
    public static PdfPCell getIRDCell10(Paragraph text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.WHITE);
        cell.setFixedHeight(80);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);

        return cell;
    }
    public static PdfPCell getIRDCell3(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (3.0f);
        cell.setBorderColor(BaseColor.WHITE);

        cell.setBackgroundColor(new BaseColor(253, 243, 198));
        return cell;
    }
    public static PdfPCell getIRDCell9(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (5.0f);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setFixedHeight(80);
        cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
        cell.setPadding (5.0f);
        cell.setPadding (5.0f);
        cell.setBackgroundColor(new BaseColor(0, 0, 0));
        return cell;
    }
    public static PdfPCell getIRDCell1(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (3.0f);
        cell.setBorderColor(BaseColor.BLACK);
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 11);
        font.setColor(BaseColor.GRAY);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        cell = new PdfPCell(phrase);

        cell.setPadding (5.0f);
        cell.setBackgroundColor(new BaseColor(224, 224, 224));
        return cell;
    }
    public static PdfPCell getIRDCell12(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (3.0f);
        BaseColor O = new BaseColor(111,45,168);
        cell.setBorderColor(O);
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 11);
        BaseColor O1 = new BaseColor(255,255,255);
        font.setColor(O1);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        cell = new PdfPCell(phrase);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        BaseColor O2 = new BaseColor(130,111,155);
        cell.setBackgroundColor(O2);
        return cell;
    }
    public static PdfPCell getIRDCell13(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setPadding (3.0f);
        BaseColor O = new BaseColor(111,45,168);
        cell.setBorderColor(O);
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 11);
        BaseColor O1 = new BaseColor(0,0,0);
        font.setColor(O1);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        cell = new PdfPCell(phrase);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        BaseColor O2 = new BaseColor(190, 153, 215);
        cell.setBackgroundColor(O2);
        return cell;
    }

    public static PdfPCell getBillHeaderCell(String text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 11);
        font.setColor(BaseColor.GRAY);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        PdfPCell cell = new PdfPCell (phrase);
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        return cell;
    }

    public static PdfPCell getBillRowCell(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setBorderWidthBottom(0);
        cell.setBorderWidthTop(0);
        return cell;
    }

    public static PdfPCell getBillFooterCell(String text) {
        PdfPCell cell = new PdfPCell (new Paragraph (text));
        cell.setHorizontalAlignment (Element.ALIGN_CENTER);
        cell.setPadding (5.0f);
        cell.setBorderWidthBottom(0);
        cell.setBorderWidthTop(0);
        return cell;
    }

    public static PdfPCell getValidityCell(String text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 10);
        font.setColor(BaseColor.GRAY);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        PdfPCell cell = new PdfPCell (phrase);
        cell.setBorder(0);
        return cell;
    }

    public static PdfPCell getAccountsCell(String text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 10);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        PdfPCell cell = new PdfPCell (phrase);
        cell.setBorderWidthRight(0);
        cell.setBorderWidthTop(0);
        cell.setPadding (5.0f);
        return cell;
    }
    public static PdfPCell getAccountsCellR(String text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 10);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        PdfPCell cell = new PdfPCell (phrase);
        cell.setBorderWidthLeft(0);
        cell.setBorderWidthTop(0);
        cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
        cell.setPadding (5.0f);
        cell.setPaddingRight(20.0f);
        return cell;
    }

    public static Paragraph getdescCell(String text) {
        FontSelector fs = new FontSelector();
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 10);
        font.setColor(BaseColor.GRAY);
        fs.addFont(font);
        Phrase phrase = fs.process(text);
        Paragraph cell = new Paragraph (phrase);

        return cell;
    }



    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                savePdf();
                savePdf1();
                savePdf2();
                savePdf3();
            } else {

                Toast.makeText(this, "Permission denied...!", Toast.LENGTH_SHORT).show();
            }
        }
    }


}



